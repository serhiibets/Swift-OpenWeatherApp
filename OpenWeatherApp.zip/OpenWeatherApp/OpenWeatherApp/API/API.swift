//
//  API.swift
//  OpenWeatherApp
//
//  Created by Serhii Bets on 6/1/23.
//

import Foundation

struct API{
    private let apiKey = "e9fa299de8a9712b970c909c001cac86"
    static let url = "https://api.openweathermap.org/data/2.5/onecall?exclude=minutely&lang=ru&units=metric&appid=e9fa299de8a9712b970c909c001cac86&"
    
//https://api.openweathermap.org/data/3.0/onecall?lat=38.54228551555425&lon=-0.11822472656946918&minutely&lang=ru&appid=e9fa299de8a9712b970c909c001cac86
}

